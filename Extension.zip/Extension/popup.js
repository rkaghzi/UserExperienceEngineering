const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const jsonBtn = document.getElementById("jsonBtn");
const excelBtn = document.getElementById("excelBtn");
const statusEl = document.getElementById("status");

function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

function updateStatus(status) {
  const isRecording = Boolean(status && status.recording);
  const count = status && typeof status.logCount === "number" ? status.logCount : 0;
  const sessionId = status && status.sessionId ? status.sessionId : "No active session";

  startBtn.disabled = isRecording;
  stopBtn.disabled = !isRecording;
  jsonBtn.disabled = count === 0;
  excelBtn.disabled = count === 0;

  statusEl.textContent = isRecording
    ? `Recording ON\nSession: ${sessionId}\nLogs: ${count}`
    : `Recording OFF\nLast session: ${sessionId}\nLogs: ${count}`;
}

async function refreshStatus() {
  const status = await sendMessage({ type: "GET_STATUS" });
  updateStatus(status);
}

startBtn.addEventListener("click", async () => {
  const status = await sendMessage({ type: "START_RECORDING" });
  updateStatus(status);
});

stopBtn.addEventListener("click", async () => {
  const status = await sendMessage({ type: "STOP_RECORDING" });
  updateStatus(status);
});

jsonBtn.addEventListener("click", async () => {
  const status = await sendMessage({ type: "DOWNLOAD_JSON" });
  updateStatus(status);
});

excelBtn.addEventListener("click", async () => {
  const status = await sendMessage({ type: "DOWNLOAD_CSV" });
  updateStatus(status);
});

refreshStatus();
