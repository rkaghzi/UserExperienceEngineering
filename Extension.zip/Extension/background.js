let recording = false;
let sessionId = null;
let logs = [];
let sequenceNumber = 0;
let lastEventTimestamp = null;

function createSessionId() {
  return `session_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function getStatus() {
  return {
    recording,
    sessionId,
    logCount: logs.length
  };
}

function sanitizeFilenamePart(value) {
  return value.replace(/[:.]/g, "-");
}

function createDownloadTimestamp() {
  return sanitizeFilenamePart(new Date().toISOString());
}

function escapeCsvCell(value) {
  const text = value == null ? "" : String(value);
  const escaped = text.replace(/"/g, "\"\"");
  return `"${escaped}"`;
}

function buildCsv(rows) {
  const headers = [
    "Session ID",
    "Seq No",
    "Event Type",
    "Timestamp",
    "Readable Time",
    "Time Since Last Event",
    "URL",
    "Element Tag",
    "Element ID",
    "Element Class",
    "Element Text"
  ];

  const lines = [headers.map(escapeCsvCell).join(",")];

  for (const row of rows) {
    lines.push(
      [
        row.session_id,
        row.sequence_number,
        row.event_type,
        row.timestamp,
        row.readable_time,
        row.time_since_last_event,
        row.url,
        row.element_tag,
        row.element_id,
        row.element_class,
        row.element_text
      ].map(escapeCsvCell).join(",")
    );
  }

  return lines.join("\r\n");
}

function triggerDownload({ content, filename, mimeType }) {
  const url = `data:${mimeType};charset=utf-8,${encodeURIComponent(content)}`;
  chrome.downloads.download({
    url,
    filename,
    saveAs: true
  });
}

async function addInitialNavigationLog() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!recording || !activeTab || !activeTab.url) {
    return;
  }

  const timestamp = Date.now();

  logs.push({
    session_id: sessionId,
    sequence_number: ++sequenceNumber,
    event_type: "navigation",
    timestamp,
    readable_time: new Date(timestamp).toLocaleString(),
    time_since_last_event: lastEventTimestamp == null ? 0 : timestamp - lastEventTimestamp,
    url: activeTab.url,
    element_tag: "",
    element_id: "",
    element_class: "",
    element_text: ""
  });

  lastEventTimestamp = timestamp;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "START_RECORDING") {
    recording = true;
    sessionId = createSessionId();
    logs = [];
    sequenceNumber = 0;
    lastEventTimestamp = null;

    addInitialNavigationLog().finally(() => {
      sendResponse(getStatus());
    });

    return true;
  }

  if (message.type === "STOP_RECORDING") {
    recording = false;
    sendResponse(getStatus());
    return false;
  }

  if (message.type === "GET_STATUS") {
    sendResponse(getStatus());
    return false;
  }

  if (message.type === "LOG_EVENT") {
    if (recording) {
      const entryTimestamp = Number(message.payload.timestamp) || Date.now();
      const logEntry = {
        session_id: sessionId,
        sequence_number: ++sequenceNumber,
        event_type: message.payload.event_type || "unknown",
        timestamp: entryTimestamp,
        readable_time: message.payload.readable_time || new Date(entryTimestamp).toLocaleString(),
        time_since_last_event: lastEventTimestamp == null ? 0 : entryTimestamp - lastEventTimestamp,
        url: message.payload.url || "",
        element_tag: message.payload.element_tag || "",
        element_id: message.payload.element_id || "",
        element_class: message.payload.element_class || "",
        element_text: message.payload.element_text || ""
      };

      logs.push(logEntry);
      lastEventTimestamp = entryTimestamp;
    }

    sendResponse({ ok: true });
    return false;
  }

  if (message.type === "DOWNLOAD_JSON") {
    triggerDownload({
      content: JSON.stringify(logs, null, 2),
      filename: `ux-logs-${createDownloadTimestamp()}.json`,
      mimeType: "application/json"
    });
    sendResponse(getStatus());
    return false;
  }

  if (message.type === "DOWNLOAD_CSV") {
    triggerDownload({
      content: buildCsv(logs),
      filename: `ux-logs-${createDownloadTimestamp()}.csv`,
      mimeType: "text/csv"
    });
    sendResponse(getStatus());
    return false;
  }

  return false;
});
