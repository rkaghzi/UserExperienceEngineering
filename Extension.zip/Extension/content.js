const DEDUPE_WINDOWS = {
  click: 300,
  input: 150,
  navigation: 250,
  scroll: 400
};

let lastEventByType = {
  click: { signature: "", timestamp: 0 },
  input: { signature: "", timestamp: 0 },
  navigation: { signature: "", timestamp: 0 },
  scroll: { signature: "", timestamp: 0 }
};

function getElementDetails(target) {
  if (!(target instanceof Element)) {
    return {
      element_tag: "",
      element_id: "",
      element_class: "",
      element_text: ""
    };
  }

  const text = (target.innerText || target.textContent || "").trim().replace(/\s+/g, " ").slice(0, 200);

  return {
    element_tag: target.tagName ? target.tagName.toLowerCase() : "",
    element_id: target.id || "",
    element_class: target.className && typeof target.className === "string" ? target.className : "",
    element_text: text
  };
}

function shouldSkipDuplicate(type, signature, timestamp) {
  const lastEvent = lastEventByType[type];
  if (lastEvent.signature === signature && timestamp - lastEvent.timestamp < DEDUPE_WINDOWS[type]) {
    return true;
  }

  lastEventByType[type] = { signature, timestamp };
  return false;
}

function sendLog(eventType, target, extra = {}) {
  const timestamp = Date.now();
  const details = getElementDetails(target);
  const payload = {
    event_type: eventType,
    timestamp,
    readable_time: new Date(timestamp).toLocaleString(),
    url: location.href,
    ...details,
    ...extra
  };

  const signature = [
    payload.event_type,
    payload.url,
    payload.element_tag,
    payload.element_id,
    payload.element_class,
    payload.element_text,
    extra.position || "",
    extra.value || ""
  ].join("|");

  if (shouldSkipDuplicate(eventType, signature, timestamp)) {
    return;
  }

  chrome.runtime.sendMessage({
    type: "LOG_EVENT",
    payload
  });
}

document.addEventListener(
  "click",
  (event) => {
    sendLog("click", event.target);
  },
  true
);

document.addEventListener(
  "input",
  (event) => {
    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }

    const inputName = target.getAttribute("name") || "";
    const inputType = target.getAttribute("type") || target.tagName.toLowerCase();

    sendLog("input", target, {
      value: `${inputName}:${inputType}`,
      element_text: inputName || inputType
    });
  },
  true
);

let scrollTimeout = null;
let lastScrollPosition = "";
window.addEventListener(
  "scroll",
  () => {
    if (scrollTimeout) {
      window.clearTimeout(scrollTimeout);
    }

    scrollTimeout = window.setTimeout(() => {
      const position = `${window.scrollX},${window.scrollY}`;

      if (position === lastScrollPosition) {
        return;
      }

      lastScrollPosition = position;

      sendLog("scroll", null, {
        position,
        element_tag: "window",
        element_id: "",
        element_class: "",
        element_text: `scroll position x:${window.scrollX}, y:${window.scrollY}`
      });
    }, 150);
  },
  { passive: true }
);

function logNavigation() {
  sendLog("navigation", document.documentElement, {
    element_text: document.title || "navigation"
  });
}

function patchHistoryMethod(methodName) {
  const originalMethod = history[methodName];
  if (typeof originalMethod !== "function") {
    return;
  }

  history[methodName] = function (...args) {
    const result = originalMethod.apply(this, args);
    window.setTimeout(logNavigation, 0);
    return result;
  };
}

patchHistoryMethod("pushState");
patchHistoryMethod("replaceState");

window.addEventListener("popstate", logNavigation);
window.addEventListener("hashchange", logNavigation);
window.addEventListener("load", logNavigation);
